import torch

managed_tensors = {}

def tensor_manage(a, key):
    print("tensor_manage pointer is:", a)
    managed_tensors[key] = a

def get_managed(key):
    if key not in managed_tensors:
        return torch.zeros(0)
    return managed_tensors[key]

def print_managed():
    for key in managed_tensors:
        print("key is:", key)
        print(managed_tensors[key])